package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setDetails() {
		fileName = "credentials";
		testName = "LoginAndLogout";
		testDescription = "Login and Logout with valid data";
		testAuthor = "Hari";
		testCategory = "Smoke";
				

	}
	
	
	@Test(dataProvider = "fetchData")
	public void loginLogout(String username, String password) throws InterruptedException, IOException {
		
		LoginPage lp = new LoginPage(driver);
		
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLogin()
		.clickLogout();
		

	}

}
