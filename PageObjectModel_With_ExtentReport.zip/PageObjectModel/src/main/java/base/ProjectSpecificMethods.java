package base;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;


import cucumber.api.testng.AbstractTestNGCucumberTests;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcelData;

public class ProjectSpecificMethods{
	
	public  ChromeDriver driver;
	
	public String fileName;
	
	public static ExtentHtmlReporter reporter;
	public static ExtentReports extent;
	public static ExtentTest test,node;
	
	public String testName,testDescription,testAuthor,testCategory;
	
	@BeforeSuite
	public void startReport() {
				reporter = new ExtentHtmlReporter("./ExtenReports/result.html");
				reporter.setAppendExisting(true);
				extent = new ExtentReports();
				extent.attachReporter(reporter);
	}
	
	@BeforeClass
	public void testCaseDetails() {
		test = extent.createTest(testName, testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);
	}
	
	
	public long takeSnap() throws IOException {
		
		long number = (long) Math.floor(Math.random()*90000000);
		
		File source = driver.getScreenshotAs(OutputType.FILE);
		File dest = new File("./snaps/"+number+".png");
		FileUtils.copyFile(source, dest);
		
		return number; //53453545.png

	}
	
	
	public void reportStep(String msg, String status) throws IOException {
		if(status.equals("pass")) {
			node.pass(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/"+takeSnap()+".png").build());
		}
		else {
			long takeSnap = takeSnap();
			node.fail(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/"+takeSnap+".png").build());
			throw new RuntimeException();
		}

	}
	
		
	
	
	@BeforeMethod
	public void preCondition() {
		node = test.createNode(testName, testDescription);
		
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");

	}
	
	@AfterMethod
	public void postCondition() {
		driver.close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
		String[][] data = ReadExcelData.readData(fileName);
		
		return data;

	}
	
	@AfterSuite
	public void endReport() {
		extent.flush();

	}
	
	

}
