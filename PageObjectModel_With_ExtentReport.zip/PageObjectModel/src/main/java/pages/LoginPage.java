package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class LoginPage extends ProjectSpecificMethods {

	public LoginPage(ChromeDriver browser) {
		driver = browser;

	}

	public LoginPage enterUsername(String username) throws IOException {
		try {
			driver.findElementById("username").sendKeys(username);
			reportStep(username + " entered successfully", "pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep(username + " not entered successfully", "fail");
		}
		return this;
	}

	public LoginPage enterPassword(String password) throws IOException {
		try {
			driver.findElementById("password").sendKeys(password);
			reportStep(password + " entered successfully", "pass");
		} catch (Exception e) {
			reportStep(password + " not entered successfully", "fail");
		}
		return this;

	}

	public HomePage clickLogin() throws IOException {
		try {
			driver.findElementByClassName("decorativeSubmit").click();
			reportStep("Login button clicked successfully", "pass");
		} catch (Exception e) {
			reportStep("Login button not clicked successfully", "fail");
		}

		return new HomePage(driver);
	}

}
