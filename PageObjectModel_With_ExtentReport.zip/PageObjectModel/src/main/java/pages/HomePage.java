package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificMethods;
import cucumber.api.java.en.Then;

public class HomePage extends ProjectSpecificMethods {

	
	  public HomePage(ChromeDriver driver) {
	  
	  this.driver = driver;
	  
	  }
	 

	public LoginPage clickLogout() throws IOException {
		try {
			driver.findElementByClassName("decorativeSubmit").click();
			reportStep("Logout button clicked successfully", "pass");
		} catch (Exception e) {
			reportStep("Logout button not clicked successfully", "fail");
		}

		return new LoginPage(driver);

	}

	@Then("homepage should be displayed")
	public HomePage verifyPageTitle() throws IOException {

		String actualTitle="";
		try {
			actualTitle = driver.getTitle();
			if (actualTitle.equals(actualTitle)) {
				reportStep("Title is matching", "pass");
			}
			else {
				reportStep("Title is not matching", "fail");
			}
			
		} catch (Exception e) {
			reportStep("Title is not matching", "fail");
		}

		

		return this;

	}

}
