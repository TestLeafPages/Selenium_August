package week7.day2;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class LearnPropertyFile {

	public static void main(String[] args) throws IOException {
		
		//set up the file path for interaction
		FileInputStream fis = new FileInputStream("./src/test/resources/English.properties");
		
		//Create object for Properties
		Properties prop = new Properties();
		
		//Load the Properties file
		prop.load(fis);
		
		System.out.println(prop.getProperty("MyHome.Leads.LinkText"));
		

	}

}
