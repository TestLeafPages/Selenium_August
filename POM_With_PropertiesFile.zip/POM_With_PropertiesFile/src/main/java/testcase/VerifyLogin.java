package testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class VerifyLogin extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setFileName() {
		fileName = "credentials";

	}
	
	@Test(dataProvider="fetchData")
	public void verifyLogin(String username,String password) throws InterruptedException {
						
		new LoginPage(driver,prop)
		.enterUsername(username)
		.enterPassword(password)
		.clickLogin()
		.verifyPageTitle();

	}

}
