package pages;

import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	
	public HomePage(ChromeDriver driver,Properties prop) {
		
		this.driver = driver;
		this.prop = prop;
		
	}
	
	public LoginPage clickLogout() {
		driver.findElementByXPath(prop.getProperty("HomePage.Logout.Xpath")).click();
		
		return new LoginPage(driver,prop);

	}
	
	
	public HomePage verifyPageTitle() {

		String actualTitle = driver.getTitle();
		
		Assert.assertEquals(actualTitle, "Leaftaps - TestLeaf Automation Platform");
		
		return this;

	}

}
