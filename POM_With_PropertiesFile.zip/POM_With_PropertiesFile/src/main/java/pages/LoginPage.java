package pages;

import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver,Properties prop){
		this.driver = driver;
		this.prop = prop;
		
	}
	
	
	//actionElementName
	public LoginPage enterUsername(String username) throws InterruptedException {
		driver.findElementById(prop.getProperty("LoginPage.Username.Id")).sendKeys(username);
		
		//Thread.sleep(3000);
		
		return this;
	}
	
	public LoginPage enterPassword(String password) {
		driver.findElementById(prop.getProperty("LoginPage.Password.Id")).sendKeys(password);
		return this;

	}
	
	public HomePage clickLogin() {
		driver.findElementByClassName(prop.getProperty("LoginPage.Login.ClassName")).click();
		
		return new HomePage(driver,prop);
	}

}
