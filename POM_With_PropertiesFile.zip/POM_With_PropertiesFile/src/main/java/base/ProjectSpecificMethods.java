package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcelData;

public class ProjectSpecificMethods {
	
	public ChromeDriver driver;
	
	public String fileName;
	
	public Properties prop;
	
	
	@Parameters({"language"})
	@BeforeMethod
	public void preCondition(String lang) throws IOException {
		//Property file setup
		//set up the file path for interaction
		FileInputStream fis = new FileInputStream("./src/main/resources/"+lang+".properties");
		
		//Create object for Properties
		prop = new Properties();
		
		//Load the Properties file
		prop.load(fis);
		
		
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");

	}
	
	@AfterMethod
	public void postCondition() {
		driver.close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
		String[][] data = ReadExcelData.readData(fileName);
		
		return data;

	}
	
	
	

}
