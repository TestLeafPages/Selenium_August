package testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setFileName() {
		fileName = "credentials";

	}
	
	
	@Test(dataProvider = "fetchData")
	public void loginLogout(String username, String password) throws InterruptedException {
		
		LoginPage lp = new LoginPage(driver);
		
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLogin()
		.clickLogout();
		

	}

}
