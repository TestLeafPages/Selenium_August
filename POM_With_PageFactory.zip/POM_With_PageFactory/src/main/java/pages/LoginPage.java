package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver){
		this.driver = driver;
		
		//Mandatory to initialize the elements
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(how=How.XPATH, using="//input") 
	List<WebElement> UName;
	
	@CacheLookup
	@FindBy(id="password")
	WebElement pword;
	
	@CacheLookup
	@FindBy(className="decorativeSubmit")
	WebElement login;
	
	
	//AND condition
	//@FindBys({
	//	@FindBy(how=How.NAME, using="USERNAME"),
	//	@FindBy(how=How.XPATH, using="//input[@id='username123']")
	//}
	//)
	
	//OR condition
	/*
	 * @FindAll({
	 * 
	 * @FindBy(how=How.NAME, using="USERNAME"),
	 * 
	 * @FindBy(how=How.ID, using="username"),
	 * 
	 * @FindBy(how=How.XPATH, using="//input[@id='username123']") } )
	 */
	
	
	
	//actionElementName
	public LoginPage enterUsername(String username) throws InterruptedException {
	//	driver.findElementById("username").sendKeys(username);
		
		UName.get(0).sendKeys(username);
		//UName.sendKeys(UName);
	
		Thread.sleep(3000);
		
		return this;
	}
	
	
	
	public LoginPage enterPassword(String password) {
		//driver.findElementById("password").sendKeys(password);
		pword.sendKeys(password);
		return this;

	}
	
	public HomePage clickLogin() {
		//driver.findElementByClassName("decorativeSubmit").click();
		login.click();
		
		return new HomePage(driver);
	}
	
	public LoginPage clickLoginForInvalidCredentials() {
		//driver.findElementByClassName("decorativeSubmit").click();
		login.click();
		
		return this;
	}
	
	
	
	

}
